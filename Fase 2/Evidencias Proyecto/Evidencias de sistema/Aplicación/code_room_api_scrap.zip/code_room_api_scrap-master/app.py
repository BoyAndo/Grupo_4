from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import uuid
import os
import asyncio
import tempfile
import shutil
from scrap import custom_playwright
import logging

# Configurar logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(title="Certificate Scraper Service", version="1.0.0")

class ScrapeRequest(BaseModel):
    url: str

class ScrapeResponse(BaseModel):
    success: bool
    data: str = None
    error: str = None
    session_id: str

@app.get("/health")
async def health_check():
    """Health check endpoint para monitoring"""
    return {
        "status": "healthy",
        "service": "certificate-scraper",
        "version": "1.0.0"
    }

@app.post("/scrape", response_model=ScrapeResponse)
async def scrape_certificate(request: ScrapeRequest):
    """
    Endpoint principal para scraping de certificados
    Maneja race conditions usando directorios temporales únicos
    """
    session_id = str(uuid.uuid4())
    temp_dir = None
    original_cwd = os.getcwd()
    
    logger.info(f"Starting scrape session {session_id} for URL: {request.url}")
    
    try:
        # Crear directorio temporal único para esta sesión
        temp_dir = tempfile.mkdtemp(prefix=f"scrape_{session_id}_")
        logger.info(f"Created temp directory: {temp_dir}")
        
        # Cambiar al directorio temporal
        os.chdir(temp_dir)
        
        # Ejecutar scraping
        result = await custom_playwright(request.url)
        
        logger.info(f"Scraping completed successfully for session {session_id}")
        
        return ScrapeResponse(
            success=True,
            data=result,
            session_id=session_id
        )
        
    except Exception as e:
        logger.error(f"Scraping failed for session {session_id}: {str(e)}")
        return ScrapeResponse(
            success=False, 
            error=str(e),
            session_id=session_id
        )
    finally:
        # Restaurar directorio original de forma segura
        try:
            if os.path.exists(original_cwd):
                os.chdir(original_cwd)
            else:
                # Si el directorio original no existe, ir a /app
                os.chdir('/app')
        except Exception as chdir_error:
            logger.warning(f"Failed to change back to original directory: {chdir_error}")
            # Como fallback, ir a /app
            try:
                os.chdir('/app')
            except Exception as fallback_error:
                logger.error(f"Failed to change to /app directory: {fallback_error}")
        
        # Limpiar directorio temporal
        if temp_dir and os.path.exists(temp_dir):
            try:
                shutil.rmtree(temp_dir)
                logger.info(f"Cleaned up temp directory for session {session_id}")
            except Exception as cleanup_error:
                logger.warning(f"Failed to cleanup temp directory: {cleanup_error}")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8002)
