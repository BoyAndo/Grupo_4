#!/usr/bin/env python3
"""
Script para probar el microservicio Python localmente
Útil para desarrollo y debugging
"""

import asyncio
import sys
import json
from app import app
from fastapi.testclient import TestClient

def test_local():
    """Prueba local del servicio sin containers"""
    
    if len(sys.argv) < 2:
        print("Usage: python test_service.py <url>")
        sys.exit(1)
    
    url = sys.argv[1]
    
    print(f"🧪 Testing Python service locally with URL: {url}")
    
    # Crear cliente de prueba
    client = TestClient(app)
    
    # Hacer request de prueba
    response = client.post("/scrape", json={"url": url})
    
    print(f"📊 Response status: {response.status_code}")
    print(f"📄 Response body:")
    print(json.dumps(response.json(), indent=2))
    
    if response.status_code == 200:
        result = response.json()
        if result.get("success"):
            print("✅ Test successful!")
        else:
            print(f"❌ Scraping failed: {result.get('error')}")
    else:
        print(f"❌ HTTP Error: {response.status_code}")

def test_health():
    """Prueba el endpoint de health"""
    client = TestClient(app)
    response = client.get("/health")
    
    print(f"🏥 Health check status: {response.status_code}")
    print(f"📄 Health response:")
    print(json.dumps(response.json(), indent=2))

if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "health":
        test_health()
    else:
        test_local()
