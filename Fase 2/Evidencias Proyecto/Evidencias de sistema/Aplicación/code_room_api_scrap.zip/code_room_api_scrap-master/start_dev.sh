#!/bin/bash

echo "🚀 Starting Python Scraper Service in Development Mode"
echo "=================================================="

# Verificar que estamos en el directorio correcto
if [ ! -f "requirements.txt" ]; then
    echo "❌ Error: requirements.txt not found. Please run from src/python directory"
    exit 1
fi

# Instalar dependencias si es necesario
echo "📦 Installing/updating dependencies..."
pip install -r requirements.txt

# Instalar playwright browsers si es necesario
echo "🌐 Setting up Playwright browsers..."
playwright install chromium

echo ""
echo "🎯 Service will be available at: http://localhost:8002"
echo "🏥 Health check endpoint: http://localhost:8002/health"
echo "📡 Scraping endpoint: POST http://localhost:8002/scrape"
echo ""
echo "🛑 Press Ctrl+C to stop the service"
echo ""

# Iniciar el servicio
python app.py
