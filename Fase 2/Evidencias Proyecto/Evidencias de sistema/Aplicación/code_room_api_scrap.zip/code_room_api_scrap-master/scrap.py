import asyncio, requests, time, whisper, os
from playwright.async_api import async_playwright, TimeoutError as PlaywrightTimeout


async def custom_playwright(url:str) -> str:
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)  # Cambiar a visible para debug
        page = await browser.new_page()
        
        # Agregar user agent más realista
        await page.set_extra_http_headers({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        })
        
        await page.goto(url)

        await page.screenshot(path="snapshot.png")
        print("Snapshot guardado.")

        await asyncio.sleep(3)  # Pausa más larga para parecer humano

        # Detección de reCAPTCHA
        captcha_frame = None
        for frame in page.frames:
            if "https://www.google.com/recaptcha/api2/anchor" in frame.url:
                captcha_frame = frame
                break

        if captcha_frame:
            print("CAPTCHA detectado. Intentando interactuar...")

            try:
                checkbox = await captcha_frame.wait_for_selector("#recaptcha-anchor", timeout=10000)
                
                # Simular movimiento humano del mouse
                box = await checkbox.bounding_box()
                if box:
                    await page.mouse.move(box['x'] + box['width']/2, box['y'] + box['height']/2)
                    await asyncio.sleep(3)  # Pausa antes del clic
                
                await checkbox.click()
                print("Click realizado en CAPTCHA.")

                await page.wait_for_timeout(5000)  # Esperar más tiempo

                desafio_frame = None
                for frame in page.frames:
                    if "https://www.google.com/recaptcha/api2/bframe" in frame.url:
                        desafio_frame = frame
                        break

                if desafio_frame:
                    print("Desafío de imágenes detectado. Intentando cambiar a audio...")
                    try:
                        audio_button = await desafio_frame.wait_for_selector("#recaptcha-audio-button", timeout=10000)
                        await audio_button.click()
                        print("Botón de audio clickeado.")

                        await asyncio.sleep(3)

                        # Rebuscar el frame de audio (a veces se recarga)
                        for frame in page.frames:
                            if "https://www.google.com/recaptcha/api2/bframe" in frame.url:
                                desafio_frame = frame
                                break

                        print("Iframe del desafío de audio detectado.")

                        # Debug: ver qué elementos están disponibles
                        try:
                            print("Elementos disponibles en el frame:")
                            elements = await desafio_frame.query_selector_all("*")
                            for i, element in enumerate(elements[:20]):  # Solo primeros 20
                                tag = await element.evaluate("el => el.tagName")
                                classes = await element.evaluate("el => el.className")
                                href = await element.evaluate("el => el.href || ''")
                                print(f"  {i}: {tag} class='{classes}' href='{href}'")
                        except Exception as debug_error:
                            print(f"Error en debug: {debug_error}")

                        # Esperar un poco más para que el audio se genere automáticamente
                        await asyncio.sleep(4)

                        # Ir directamente al enlace de descarga (sin hacer clic en botón de audífonos)
                        try:
                            print("Buscando enlace de descarga de audio...")
                            
                            # Intentar múltiples selectores para el enlace de descarga
                            download_link = None
                            selectors = [
                                ".rc-audiochallenge-tdownload-link",
                                "a[href*='recaptcha/api2/payload']",
                                ".rc-audiochallenge-download-link",
                                "#audio-source"
                            ]
                            
                            for selector in selectors:
                                try:
                                    print(f"Intentando selector: {selector}")
                                    download_link = await desafio_frame.wait_for_selector(selector, timeout=8000)
                                    print(f"Enlace encontrado con selector: {selector}")
                                    break
                                except PlaywrightTimeout:
                                    print(f"Selector {selector} no encontrado, probando siguiente...")
                                    continue
                            
                            if not download_link:
                                raise Exception("No se encontró ningún enlace de descarga de audio")
                            audio_url = await download_link.get_attribute("href")

                            if audio_url:
                                print(f"URL de audio encontrada: {audio_url}")
                                
                                # Descargar con headers apropiados
                                headers = {
                                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
                                    "Referer": url
                                }
                                response = requests.get(audio_url, headers=headers)
                                
                                if response.status_code == 200 and len(response.content) > 0:
                                    with open("captcha_audio.mp3", "wb") as f:
                                        f.write(response.content)
                                    print(f"Audio descargado correctamente, tamaño: {len(response.content)} bytes")
                                else:
                                    print(f"Error al descargar: Status {response.status_code}, Tamaño: {len(response.content)} bytes")
                                    raise Exception("Descarga de audio falló")

                                await asyncio.sleep(3)

                                audio_path = "captcha_audio.mp3"
                                if os.path.exists(audio_path):
                                    print("El archivo de audio existe, se procederá a transcribir.")
                                    try:
                                        print("Cargando modelo Whisper...")
                                        model = whisper.load_model("medium")
                                        print("Transcribiendo audio del CAPTCHA...")
                                        result = model.transcribe(audio_path, fp16=False)
                                        transcribed_text = result["text"].strip()
                                        print(f"Texto transcrito del audio: '{transcribed_text}'")
                                    except Exception as whisper_error:
                                        print(f"Error en transcripción con Whisper: {whisper_error}")
                                        print("Usando placeholder como fallback")
                                        transcribed_text = "captcha_error"
                                else:
                                    print("Error: El archivo captcha_audio.mp3 no fue encontrado.")
                                    transcribed_text = "audio_not_found"

                                try:
                                    print("Buscando input para respuesta de audio...")
                                    input_box = await desafio_frame.wait_for_selector('input#audio-response', timeout=5000)
                                    await input_box.fill(transcribed_text)
                                    print("Respuesta escrita en el input.")

                                    await asyncio.sleep(3)

                                    verify_button = await desafio_frame.wait_for_selector('#recaptcha-verify-button', timeout=5000)
                                    await verify_button.click()
                                    print("Botón 'Verificar' presionado.")

                                    await asyncio.sleep(3)

                                except Exception as e:
                                    print(f"Error al interactuar con el input o botón de verificación: {e}")
                            else:
                                print("No se encontró la URL del audio.")
                        except Exception as e:
                            print("Error al intentar extraer o descargar el audio:", e)
                    except PlaywrightTimeout:
                        print("No se encontró el botón de audio o falló el clic.")
                else:
                    print("No apareció el desafío visual.")
            except PlaywrightTimeout:
                print("No se pudo hacer clic en el CAPTCHA.")
        else:
            print("No se detectó CAPTCHA. Continuando...")

        # Extraer texto de la página final
        try:
            await page.wait_for_load_state("load", timeout=10000)
            texto = await page.inner_text("body")
            print("Contenido visible de la página:")
            
            # Guardar contenido para debug (opcional)
            with open("pagina_final.txt", "w", encoding="utf-8") as f:
                f.write(texto)
            print("Contenido guardado en pagina_final.txt")
            
            return texto
        except PlaywrightTimeout:
            print("La página tardó demasiado en cargar o falló.")
            return ""
        finally:
            await browser.close()


if __name__ == "__main__":
    import sys
    
    if len(sys.argv) < 2:
        print("Usage: python scrap.py <url>")
        sys.exit(1)
    
    url = sys.argv[1]
    print(f"Procesando URL: {url}")
    
    try:
        resultado = asyncio.run(custom_playwright(url))
        print(resultado)  # Esto es lo que va a parseStudentInfo
    except Exception as e:
        print(f"Error en el scraping: {e}")
        sys.exit(1)

