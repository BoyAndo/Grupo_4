# Certificate Scraper Service 🔍

Microservicio FastAPI para scraping automatizado de certificados educativos chilenos con resolución de CAPTCHA usando OpenAI Whisper.

## 🚀 Características

- ✅ **Scraping automatizado** de certificados de USS y DUOC
- ✅ **Resolución automática de CAPTCHA** usando Whisper para transcripción de audio
- ✅ **Arquitectura sin race conditions** - cada request usa directorio temporal aislado
- ✅ **API REST** con FastAPI y documentación automática
- ✅ **Health checks** para monitoreo y alta disponibilidad
- ✅ **Containerización** con Docker para despliegue fácil
- ✅ **Escalabilidad horizontal** - múltiples instancias simultáneas

## 🏗️ Arquitectura

```
┌─────────────────┐    HTTP POST     ┌─────────────────┐
│   Cliente       │ ────────────────▶│  FastAPI        │
│   (Node.js/Web) │◀──── JSON ───────│  Certificate    │
└─────────────────┘                  │  Scraper        │
                                     └─────────────────┘
                                            │
                                            ▼
                                     ┌─────────────────┐
                                     │  Playwright     │
                                     │  + Whisper      │
                                     │  + Chrome       │
                                     └─────────────────┘
```

## 📡 API Endpoints

### `POST /scrape`

Endpoint principal para scraping de certificados.

**Request de prueba localgit push origin --delete main:**

```json
{
  "url": "https://certificadovalida.duoc.cl/ValidacionQr?id=1357556946"
}
```

**Response exitosa:**

```json
{
  "success": true,
  "data": "Certificado Vigente\\nEmitido el 14/05/2025\\n\\nCERTIFICADO DE ALUMNO REGULAR...",
  "session_id": "uuid-here",
  "error": null
}
```

### `GET /health`

Health check para monitoreo.

**Response:**

```json
{
  "status": "healthy",
  "service": "certificate-scraper",
  "version": "1.0.0"
}
```

## 🛠️ Instalación y Desarrollo

### Prerrequisitos

- Python 3.11+
- ffmpeg (para Whisper)

### Desarrollo local

```bash
# Clonar repositorio
git clone https://github.com/BoyAndo/code_room_api_scrap.git
cd code_room_api_scrap

# Instalar dependencias
pip install -r requirements.txt

# Instalar browsers de Playwright
playwright install chromium

# Ejecutar en modo desarrollo
python app.py
```

### Scripts de desarrollo

```bash
# Windows
start_dev.bat

# Linux/Mac
chmod +x start_dev.sh
./start_dev.sh
```

### Testing

```bash
# Test health check
python test_service.py health

# Test scraping
python test_service.py "https://certificadovalida.duoc.cl/ValidacionQr?id=1357556946"
```

## 🐳 Docker

### Build imagen

```bash
docker build -t certificate-scraper .
```

### Ejecutar container

```bash
docker run -p 8002:8002 certificate-scraper
```

### Con Docker Compose

```yaml
services:
  certificate-scraper:
    build: .
    ports:
      - "8002:8002"
    environment:
      - PYTHONUNBUFFERED=1
    restart: unless-stopped
```

## 🌐 Integración

### Node.js/Express

```javascript
const response = await fetch("http://localhost:8002/scrape", {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({ url: certificateUrl }),
});

const result = await response.json();
if (result.success) {
  console.log("Certificate data:", result.data);
}
```

### Python

```python
import requests

response = requests.post('http://localhost:8002/scrape',
  json={'url': 'https://certificadovalida.duoc.cl/ValidacionQr?id=123'})

result = response.json()
if result['success']:
    print('Certificate data:', result['data'])
```

## 🔧 Variables de Entorno

| Variable                   | Descripción         | Default            |
| -------------------------- | ------------------- | ------------------ |
| `PORT`                     | Puerto del servicio | `8002`             |
| `PYTHONUNBUFFERED`         | Output sin buffer   | `1`                |
| `PLAYWRIGHT_BROWSERS_PATH` | Ruta browsers       | `/app/.playwright` |

## 📊 Rendimiento

- **Tiempo promedio**: ~15-30 segundos por certificado
- **CAPTCHA success rate**: ~90%+
- **Memoria**: ~1-2GB por instancia
- **Concurrencia**: Ilimitada (cada request aislado)

## 🔐 Seguridad

- Cada sesión usa directorio temporal único
- Limpieza automática de archivos temporales
- Sin persistencia de datos sensibles
- Contenedor aislado

## 🚨 Troubleshooting

### Error: "Browsers not found"

```bash
playwright install chromium
```

### Error: "ffmpeg not found"

```bash
# Ubuntu/Debian
sudo apt-get install ffmpeg

# macOS
brew install ffmpeg

# Windows
# Descargar desde https://ffmpeg.org/
```

### CAPTCHA no se resuelve

- Verificar que Whisper modelo 'small' se descargue correctamente
- Revisar logs para errores de audio transcription
- El sistema usa fallbacks automáticos

## 📈 Monitoreo

### Health Checks

```bash
curl http://localhost:8002/health
```

### Logs

Los logs incluyen:

- Session ID para tracking
- Tiempos de ejecución
- Errores detallados
- Limpieza de recursos

## 🤝 Contribución

1. Fork el repositorio
2. Crear feature branch (`git checkout -b feature/amazing-feature`)
3. Commit changes (`git commit -m 'Add amazing feature'`)
4. Push to branch (`git push origin feature/amazing-feature`)
5. Abrir Pull Request

## 📄 Licencia

MIT License - ver [LICENSE](LICENSE) para detalles.

## 🙏 Agradecimientos

- [Playwright](https://playwright.dev/) para web automation
- [OpenAI Whisper](https://github.com/openai/whisper) para transcripción de audio
- [FastAPI](https://fastapi.tiangolo.com/) para la API REST
